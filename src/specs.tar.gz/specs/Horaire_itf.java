
public interface Horaire_itf {
	public int getHeures();
	public void setHeures(int h);
	
	public int getMinutes();
	public void setMinutes(int h);
}
