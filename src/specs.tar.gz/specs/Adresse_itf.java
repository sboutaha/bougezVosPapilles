
public interface Adresse_itf {
	public String getVille();
	public void setVille(String v);
	
	public String getVoie();
	public void setVoie(String v);
}
