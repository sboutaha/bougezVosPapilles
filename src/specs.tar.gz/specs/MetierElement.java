/** Facade pour les beans constituants la partie métier */

public interface MetierElement {

}
