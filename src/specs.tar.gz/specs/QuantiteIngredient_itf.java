
public interface QuantiteIngredient_itf {
	public int getQuantite();
	public void setQuantite(int q);
	
	public Ingredient_itf getIngredient();
	public void setIngredient(Ingredient_itf ing);
}
