
public class CommandeEmporter extends Commande {

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return Commande_itf.A_EMPORTER;
	}
	
}