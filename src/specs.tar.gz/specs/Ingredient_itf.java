
public interface Ingredient_itf {
	public void setNom(String _nom);
	public String getNom();
}
