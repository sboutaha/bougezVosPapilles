
public interface Creneau_itf {
	public Horaire_itf getHeureDebut();
	public void setHeureDebut(Horaire_itf h);
	
	public Horaire_itf getHeureFin();
	public void setHeureFin(Horaire_itf h);
}
